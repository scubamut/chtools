*** IMPORTANT! ***

Install the package in development mode:

cd COMPANIES-HOUSE_PROJECT/companies_house

pip install -e .